<a name="unreleased"></a>
## [Unreleased]

<a name="v0.0.2"></a>
## [v0.0.2] - 2019-09-03
### Changed
- Moved project api version to keikoproj.io

<a name="v0.0.1"></a>
## [v0.0.1] - 2019-08-14
### Added
- Initial Release of Addon Manager

[Unreleased]: https://github.com/keikoproj/addon-manager/compare/v0.0.2...HEAD
[v0.0.2]: https://github.com/keikoproj/addon-manager/compare/v0.0.1...v0.0.2
[v0.0.1]: https://github.com/keikoproj/addon-manager/releases/tag/v0.0.1
